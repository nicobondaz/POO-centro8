package ar.org.trabajo.centro8.java.entidades;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public final class Colectivo extends Vehiculo {


    public Colectivo(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    @Override 
    public void tipoVehiculo() {
        System.out.println("Es un colectivo");
    }

}
