package ar.org.trabajo.centro8.java.testVehiculos;

import ar.org.trabajo.centro8.java.entidades.AutoClasico;
import ar.org.trabajo.centro8.java.entidades.AutoNuevo;
import ar.org.trabajo.centro8.java.entidades.Colectivo;
import ar.org.trabajo.centro8.java.entidades.Radio;

public class TestVehiculos {
    public static void main(String[] args) {
        
        Radio radio1 = new Radio("Sony", "X123", false);
        Radio radio2 = new Radio("Pioneer", "X456", false);
        Radio radio3 = new Radio("JVC", "X789", false);

        System.out.println("-----------------");

        AutoNuevo autoNuevo1 = new AutoNuevo("Toyota", "Corolla", "Rojo", radio1);

        autoNuevo1.setPrecio(300000.00);
        autoNuevo1.agregarRadio(radio1);
        System.out.println(autoNuevo1.toString());
        autoNuevo1.tipoVehiculo();

        // AutoNuevo autoNuevo2 = new AutoNuevo("Honda", "Civic", "Azul");


        System.out.println("-----------------");


        AutoClasico autoClasico1 = new AutoClasico("Ford", "Mustang", "Negro");

        autoClasico1.setPrecio(500000.00);
        autoClasico1.agregarRadio(radio2);
        autoClasico1.quitarRadio();
        System.out.println(autoClasico1.toString());
        autoClasico1.tipoVehiculo();

        System.out.println("-----------------");

        Colectivo colectivo1 = new Colectivo("Mercedes-Benz", "Sprinter", "Blanco");

        colectivo1.setPrecio(800000.00);
        colectivo1.agregarRadio(radio2);
        colectivo1.tipoVehiculo();
        System.out.println(colectivo1.toString());






    }
}
