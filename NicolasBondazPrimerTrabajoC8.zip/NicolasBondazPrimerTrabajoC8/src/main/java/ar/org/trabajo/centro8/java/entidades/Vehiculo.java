package ar.org.trabajo.centro8.java.entidades;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public abstract class Vehiculo {

    private String marca;
    private String modelo;
    private String color;
    private Double precio;
    @Setter(AccessLevel.NONE)
    private Radio radio;


    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

/**
 * Este metodo verifica si el vehiculo ya tiene una radio, en caso de que no la tenga agrega una radio al vehiculo
 * y marca la radio como asignada cambiando el valor booleano de radioAsignada a true
 * @param radio
 * @param radioAsignada
 */
    public void agregarRadio(Radio radio){
        if (this.radio == null) {
            if (!radio.isRadioAsignada()) {
                this.radio = radio;
                radio.setRadioAsignada(true);
            } else {
                System.out.println("Esta radio ya está asignada a otro vehículo.");
            }
        }else{
            System.out.println("Ya tiene una radio asignada");
        }
    }

// este metodo le quita la radio al vehiculo y cambia el valor booleano de radioAsignada a false para que la radio pueda ser asignada a otro vehiculo
    public void quitarRadio(){
        if (this.radio != null) {
            this.radio.setRadioAsignada(false);
            this.radio = null;
        }
    }
// este metodo es abstracto para que lo implemten las clases hijas y cada una exprese su tipo de vehiculo
    public abstract void tipoVehiculo();
    

}
