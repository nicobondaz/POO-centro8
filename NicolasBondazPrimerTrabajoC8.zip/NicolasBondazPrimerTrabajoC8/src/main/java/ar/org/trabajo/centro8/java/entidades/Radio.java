package ar.org.trabajo.centro8.java.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Radio {
    private String marca;
    private String potencia;
    private boolean radioAsignada; //creo esta variable para analizarla en la logica de la clase Vehiculo 
                                   //para saber si la radio esta asignada a un vehiculo o no

    
    public Radio(String marca, String potencia, boolean radioAsignada) {
        this.marca = marca;
        this.potencia = potencia;
        this.radioAsignada = radioAsignada;
    }

   

    

    
}
