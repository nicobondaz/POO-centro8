package ar.org.trabajo.centro8.java.entidades;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class AutoClasico extends Vehiculo {
    

    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
        
    }

    @Override
    public void tipoVehiculo() {
        System.out.println("Es un auto clasico");
    }

    }

    


