package ar.org.trabajo.centro8.java.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString(callSuper = true)
public class AutoNuevo extends Vehiculo {

    /*
     * este constructor analiza si el radio es nulo y lanza una excepcion en caso de que lo sea
     * si no es nulo lo agrega al vehiculo
     */
    public AutoNuevo(String marca, String modelo, String color, Radio radio) {
        super(marca, modelo, color);
        if (radio == null || radio.isRadioAsignada()) {
            throw new IllegalArgumentException("La radio no puede ser nula o estar en mas de un vehiculo a la vez");
        }
        agregarRadio(radio);
    }

    @Override
    public void tipoVehiculo() {
        System.out.println("Es un auto nuevo");
    }

    @Override
    public void quitarRadio(){
        System.out.println("No se puede dejar un auto nuevo sin radio.");
        System.out.println("Para cambiar la radio existente, llame el metodo cambiarRadio");
    }
    
    
    // Este metodo lo utilizamos para cambiar la Radio quitandola y agregando otra en el mismo metodo,
    // ya que si lo hacemos solo con el metodo quitarRadio, para luego usar el metodo cambiarRadio se rompe el codigo
    public void cambiarRadio(Radio radio){
        super.quitarRadio();
        agregarRadio(radio);
    }





    
}
