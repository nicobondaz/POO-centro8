package ar.org.trabajo.centro8.java.entidades;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class AutoNuevo extends Vehiculo {

    /*
     * este constructor analiza si el radio es nulo y lanza una excepcion en caso de que lo sea
     * si no es nulo lo agrega al vehiculo
     */
    public AutoNuevo(String marca, String modelo, String color, Radio radio) {
        super(marca, modelo, color);
        if (radio == null || radio.isRadioAsignada()) {
            throw new IllegalArgumentException("El radio no puede ser nulo");
        }
        agregarRadio(radio);
    }

    @Override
    public void tipoVehiculo() {
        System.out.println("Es un auto nuevo");
    }

    


    
}
